import { FC } from 'react';

import Carousel from 'nuka-carousel';
import Link from 'next/link';
import { REPO_URL } from './utils';

interface HomeProps {}

const Home: FC<HomeProps> = ({}) => {
  const images = [
    '/book.png',
    '/book2.png',
    '/book3.png',
    '/book4.png',
    '/book5.png',
    '/book.png',
  ];

  return (
    <section id="home">
      <div className="container  py-16 mx-auto">
        <div className="items-center lg:flex">
          <div className="w-full ">
            <div>
              <h1 className="min-w-fit  lg:text-3xl font-semibold text-gray-800 dark:text-white lg:text-[52px]">
                {'Welcome to '}{' '}
                <span className="text-blue-500 ">LibroWave</span>
              </h1>

              <p className="mt-3 text-gray-600 dark:text-gray-400 lg:text-lg pt-5">
                Discover a world of knowledge with our vast collection of books.
                Rent or buy, <br />
                the choice is yours.
              </p>

              <Link href={REPO_URL} target="_blank">
                <button
                  className="animate-pulse w-fit   px-5 py-2 mt-6 text-sm
                    tracking-wider text-white uppercase transition-colors
                    duration-300 transform bg-blue-600 rounded-lg lg:w-auto
                    hover:bg-blue-500 focus:outline-none focus:bg-blue-500"
                >
                  Join us Now!
                </button>
              </Link>
            </div>
          </div>

          {/* <Image
                  layout="fill"
                  className="w-full h-full lg:max-w-3xl"
                  style={{ objectFit: 'cover' }}
                  src="/book.png"
                  alt="Catalogue-pana.svg"
                /> */}

          <Carousel
            cellAlign="center"
            dragThreshold={0.2}
            slidesToShow={2}
            slideIndex={2}
            cellSpacing={-10}
            wrapAround={true}
            autoplayInterval={3000}
            autoplay={true}
            className="bg-[#EFEFEF] shadow-sm p-4 rounded-md max-w-[80vw] lg:max-w-[60vw]"
            renderCenterRightControls={({ nextSlide }) => (
              <button
                // ref={nextButtonRef}
                // className="hidden"
                onClick={() => {
                  nextSlide();
                }}
              />
            )}
            renderCenterLeftControls={({ previousSlide }) => (
              <button
                // ref={prevButtonRef}
                // className="hidden"
                onClick={() => {
                  previousSlide();
                }}
              />
            )}
            // wrapAround={true}
          >
            {images.map((image, index) => (
              <img
                key={index}
                className="w-fit h-[500px]  overflow-hidden"
                src={image}
                alt="Catalogue-pana.svg"
              />
            ))}
          </Carousel>
        </div>
      </div>
    </section>
  );
};

export default Home;
