export const REPO_URL =
  'https://github.com/Kikin90/DESmaster/tree/main/Prototipo%20Final%20LibroWave';
