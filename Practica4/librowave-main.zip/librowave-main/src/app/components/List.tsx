import { FC } from 'react';

interface ListProps extends React.HTMLAttributes<HTMLDivElement> {}

interface Card {
  title: string;
  description: string;
}

const cards: Card[] = [
  {
    title: 'Discover with Ease',
    description: `Quickly find your next favorite read with LibroWave's intuitive search and exploration features.`,
  },
  {
    title: 'Rent with a Click',
    description: `LibroWave simplifies book rentals, allowing you to reserve and rent with just a few clicks`,
  },
  {
    title: 'Librarian Tools',
    description: `Empower librarians with easy-to-use tools for managing book collections efficiently.`,
  },
  {
    title: 'Friendly Community',
    description: `Join a community where readers connect, share recommendations, and explore a world of books together.`,
  },
];

const List: FC<ListProps> = ({ ...props }) => {
  return (
    <section className="bg-white dark:bg-gray-900" {...props}>
      <div className="container px-6 py-10 mx-auto min-h-[90vh]">
        <h1 className="text-2xl font-semibold text-gray-800 capitalize lg:text-3xl dark:text-white">
          {'Why use '}
          <span className="text-blue-500 ">LibroWave</span> ?
        </h1>

        <div className="mt-2">
          <span className="inline-block w-40 h-1 bg-blue-500 rounded-full"></span>
          <span className="inline-block w-3 h-1 ml-1 bg-blue-500 rounded-full"></span>
          <span className="inline-block w-1 h-1 ml-1 bg-blue-500 rounded-full"></span>
        </div>

        <div className="mt-8 xl:mt-12 lg:flex lg:items-center">
          <div className="grid w-full grid-cols-1 gap-8 lg:w-1/2 xl:gap-16 md:grid-cols-2">
            {cards.map((card, index) => (
              <div className="space-y-3" key={index}>
                <span className="inline-block p-3 text-blue-500 bg-blue-100 rounded-xl dark:text-white dark:bg-blue-500">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="w-6 h-6"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"
                    />
                  </svg>
                </span>

                <h1 className="text-xl font-semibold text-gray-700 capitalize dark:text-white">
                  {card.title}
                </h1>

                <p className="text-gray-500 dark:text-gray-300">
                  {card.description}
                </p>
              </div>
            ))}
          </div>
          <div className="hidden  lg:flex lg:w-1/2 lg:justify-center">
            <img
              className="w-[30vw] h-[30vw] flex-shrink-0 object-cover  rounded-full"
              src="https://images.unsplash.com/photo-1583526241256-cb18e8635e5b?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
              alt=""
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default List;
