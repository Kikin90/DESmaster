'use client';

import { FC } from 'react';
import Navbar from './components/Navbar';
import List from './components/List';
import Pricing from './components/Pricing';
import Contact from './components/Contact';
import Footer from './components/Footer';
import Home from './components/Home';

interface pageProps {}

const page: FC<pageProps> = ({}) => {
  return (
    <div className="bg-white items-center w-full ">
      <div>
        <Navbar />
      </div>
      <div className="mx-auto w-full flex flex-col items-stretch gap-4 max-w-full md:max-w-[80vw] ">
        <Home />
        <List id="about" />
        <Pricing id="pricing" />
        <Contact id="contact" />
        <Footer />
      </div>
    </div>
  );
};

export default page;
